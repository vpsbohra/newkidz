import React, { useEffect, useState } from 'react';
import kid1 from '../../images/kid1.png';
import brother from '../../images/brother.png';
import Vector from '../../images/Vector (2).png';
import ParentalSwitch from '../../images/Home.png';
import DarkBlue_Home from '../../images/DarkBlue_Home.png';
import blueTheme_Home from '../../images/blueTheme_Home.png';

import orangeTheme_Home from '../../images/orangeTheme_Home.png';
import pinkTheme_Home from '../../images/pinkTheme_Home.png';
import purpleTheme_Home from '../../images/purpleTheme_Home.png';

import AuthUser from '../AuthUser';
import { Link, useNavigate, Routes, Route } from 'react-router-dom';
import getToKnow from '../Audio/getToKnow.wav';
import hasResponded from '../Audio/hasResponded.wav';

const ChosenStory = () => {
  const navigate = useNavigate();
  const { http } = AuthUser();
  const [username, setUsername] = useState('');
  const { user, token } = AuthUser();
  const [userdetail, setUserdetail] = useState({});
  const userInfo = sessionStorage.getItem('user');
  const userInfoDetail = JSON.parse(userInfo);
  const spouse = userInfoDetail.spouse;
  const [storiesImage, setStoriesImage] = useState('');
  const [storiesTitle, setStoriesTitle] = useState('');
  const image = sessionStorage.getItem("selectedStory");
  const img = JSON.parse(image);

  useEffect(() => {
    setStoriesImage(img.cover_image);
    setStoriesTitle(img.title)
  }, [img.cover_image]);


  useEffect(()=>{
    const theme = sessionStorage.getItem("theme");
    document.body.classList.add(theme);
    },[sessionStorage.getItem("theme")])

    
  const fetchUserDetail = () => {
    setUserdetail(user);
    setUsername(user.name.split(' ')[0]);
  };


  useEffect(() => {
    fetchUserDetail();

  }, []);



  const sendNotification = () => {


    const audioFile = new File([getToKnow], 'audio.wav', { type: 'audio/wav' });
    const reader = new FileReader();
    reader.readAsDataURL(audioFile);
    reader.onloadend = function () {
      const base64Audio = reader.result.split(',')[1];



      const childId = sessionStorage.getItem('childId');
      const senderId = childId;
      const receiverId = userdetail.id;
      const question_voice = base64Audio;
      const question_voice_answer = "Get to know your child:Explore your child's responses to gain deeper insights into their thoughts and perspectives.";
      http
        .post('https://mykidz.online/api/first-notification', { username, senderId, receiverId, spouse,question_voice_answer,question_voice })
        .then((data) => {
          console.log(data);
          navigate('/openbook');
        })
        .catch((error) => {
          console.error('Error sending audio message:', error);
        })
    }
  }


  const sendNotification1 = () => {
    const audioFile = new File([getToKnow], 'audio.wav', { type: 'audio/wav' });
    const reader = new FileReader();
    reader.readAsDataURL(audioFile);
    reader.onloadend = function () {
      const base64Audio = reader.result.split(',')[1];
      const question_voice = base64Audio;
    const childId = sessionStorage.getItem('childId');
    const senderId = childId;
    const receiverId = userdetail.id;
    const question_voice_answer = "Get to know your child:Explore your child's responses to gain deeper insights into their thoughts and perspectives.";
    http
      .post('https://mykidz.online/api/first-notification', { username, senderId, receiverId, spouse, question_voice_answer,question_voice })
      .then((data) => {
        console.log(data);
        navigate('/code');
      })
      .catch((error) => {
        console.error('Error sending audio message:', error);
      })
    }
  }

  return (
    <>
      <div className='chosen-story-section'>
        <div className='start_book_topLeft'>
          <Link className="nav-link" to="/kids-view">
          <img className="defaultHome" loading="lazy" src={ParentalSwitch} alt='' />
          <img className="DarkBlue_HomeIn defaultHome" loading="lazy" src={DarkBlue_Home} alt='' />
          <img className="blueTheme_HomeIn defaultHome" loading="lazy" src={blueTheme_Home} alt='' />
          <img className="orangeTheme_HomeIn defaultHome" loading="lazy" src={orangeTheme_Home} alt='' />
          <img className="pinkTheme_HomeIn defaultHome" loading="lazy" src={pinkTheme_Home} alt='' />
          <img className="purpleTheme_HomeIn defaultHome" loading="lazy" src={purpleTheme_Home} alt='' />

            </Link>
        </div>
        <div className='main-container-story chosenbook_page' >
          <div className='story-display-section'>
            <img loading="lazy" className='book_cover_imgsr' src={img.image_path} alt='' />
            <div className='startbook_content'>
              <h2>{storiesTitle}</h2>
            </div>
          </div>


          <div className='reading-mode'>
            <div className='myself-section reading_btnsr'>
              <Link className="nav-link" onClick={sendNotification}  >
                <img loading="lazy" src={kid1} />
                <p>READ BY MYSELF</p>
                <svg width="38" height="34" viewBox="0 0 38 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M18.1197 5.4741V9.88896H5.11448C4.64793 9.88888 4.18594 9.9807 3.75489 10.1592C3.32384 10.3377 2.93217 10.5993 2.60225 10.9292C2.27233 11.259 2.01061 11.6507 1.83206 12.0817C1.6535 12.5127 1.5616 12.9747 1.5616 13.4412V20.547C1.5616 21.0135 1.6535 21.4755 1.83206 21.9065C2.01061 22.3375 2.27233 22.7291 2.60225 23.059C2.93217 23.3889 3.32384 23.6505 3.75489 23.829C4.18594 24.0075 4.64793 24.0993 5.11448 24.0992H18.1197V28.5141C18.1193 29.2169 18.3274 29.904 18.7177 30.4885C19.108 31.073 19.6628 31.5286 20.3121 31.7976C20.9614 32.0667 21.6759 32.1371 22.3652 31.9999C23.0545 31.8628 23.6876 31.5243 24.1844 31.0272L35.7044 19.5072C36.0346 19.1773 36.2966 18.7855 36.4754 18.3543C36.6541 17.9231 36.7461 17.4609 36.7461 16.9941C36.7461 16.5273 36.6541 16.0651 36.4754 15.6339C36.2966 15.2027 36.0346 14.8109 35.7044 14.481L24.1844 2.96227C23.6876 2.46526 23.0546 2.12674 22.3655 1.98955C21.6763 1.85236 20.9619 1.92266 20.3127 2.19155C19.6635 2.46044 19.1086 2.91584 18.7182 3.50014C18.3279 4.08444 18.1196 4.7714 18.1197 5.4741Z" fill="#FFB579" />
                  <path d="M21.7038 33.3354C22.3316 33.3334 22.9528 33.2068 23.5312 32.9629C24.1097 32.7191 24.6341 32.3629 25.0739 31.9149L36.5939 20.3949C37.4943 19.4922 38 18.2692 38 16.9941C38 15.719 37.4943 14.496 36.5939 13.5933L25.0739 2.07327C24.4013 1.40063 23.5443 0.942561 22.6114 0.756979C21.6784 0.571396 20.7114 0.66664 19.8326 1.03066C18.9537 1.39469 18.2026 2.01114 17.6741 2.80207C17.1457 3.593 16.8636 4.52287 16.8636 5.4741V8.63243H5.11496C3.84005 8.63392 2.61778 9.14104 1.71629 10.0425C0.814785 10.944 0.307663 12.1663 0.306168 13.4412V20.547C0.307663 21.8219 0.814785 23.0441 1.71629 23.9456C2.61778 24.8471 3.84005 25.3543 5.11496 25.3558H16.8636V28.5141C16.8537 29.4675 17.1318 30.4018 17.6616 31.1945C18.1914 31.9873 18.9481 32.6017 19.8329 32.9572C20.4255 33.2054 21.0614 33.3339 21.7038 33.3354ZM21.7001 3.16772C21.9983 3.16951 22.2932 3.23084 22.5675 3.34812C22.8417 3.46539 23.0898 3.63624 23.2971 3.85065L34.8171 15.3706C35.2468 15.8017 35.4881 16.3855 35.4881 16.9941C35.4881 17.6027 35.2468 18.1865 34.8171 18.6175L23.2971 30.1375C22.976 30.4588 22.5669 30.6776 22.1214 30.7663C21.6759 30.8549 21.2141 30.8095 20.7945 30.6357C20.3748 30.462 20.0161 30.1676 19.7638 29.79C19.5114 29.4123 19.3767 28.9683 19.3767 28.5141V24.0992C19.3767 23.766 19.2443 23.4464 19.0087 23.2107C18.773 22.9751 18.4534 22.8427 18.1202 22.8427H5.11496C4.50636 22.8418 3.92292 22.5997 3.49257 22.1694C3.06222 21.739 2.82009 21.1556 2.81926 20.547V13.4412C2.82009 12.8326 3.06222 12.2492 3.49257 11.8188C3.92292 11.3885 4.50636 11.1463 5.11496 11.1455H18.1202C18.4534 11.1455 18.773 11.0131 19.0087 10.7775C19.2443 10.5418 19.3767 10.2222 19.3767 9.88897V5.4741C19.3681 5.01812 19.4993 4.57043 19.7527 4.19124C20.0061 3.81205 20.3695 3.51954 20.7941 3.35306C21.0809 3.23221 21.3888 3.16923 21.7001 3.16772Z" fill="white" />
                </svg>
              </Link>
            </div>
            <div className='to-me-section reading_btnsr'>
              <Link className="nav-link" onClick={sendNotification1}  >
                <img loading="lazy" src={brother} />
                <p>READ IT TO ME</p>
                <svg width="39" height="34" viewBox="0 0 39 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M18.4674 5.4741V9.88896H5.46213C4.99559 9.88888 4.5336 9.9807 4.10255 10.1592C3.6715 10.3377 3.27983 10.5993 2.94991 10.9292C2.61998 11.259 2.35827 11.6507 2.17971 12.0817C2.00116 12.5127 1.90926 12.9747 1.90926 13.4412V20.547C1.90926 21.0135 2.00116 21.4755 2.17971 21.9065C2.35827 22.3375 2.61998 22.7291 2.94991 23.059C3.27983 23.3889 3.6715 23.6505 4.10255 23.829C4.5336 24.0075 4.99559 24.0993 5.46213 24.0992H18.4674V28.5141C18.467 29.2169 18.6751 29.904 19.0653 30.4885C19.4556 31.073 20.0105 31.5286 20.6598 31.7976C21.309 32.0667 22.0235 32.1371 22.7128 31.9999C23.4021 31.8628 24.0352 31.5242 24.5321 31.0272L36.0521 19.5072C36.3823 19.1773 36.6443 18.7855 36.823 18.3543C37.0017 17.9231 37.0937 17.4609 37.0938 16.9941C37.0937 16.5273 37.0017 16.0651 36.823 15.6339C36.6443 15.2027 36.3823 14.8109 36.0521 14.481L24.5321 2.96226C24.0353 2.46525 23.4023 2.12674 22.7131 1.98955C22.0239 1.85236 21.3096 1.92266 20.6603 2.19154C20.0111 2.46043 19.4562 2.91584 19.0659 3.50014C18.6755 4.08444 18.4672 4.77139 18.4674 5.4741Z" fill="#80DEEA" />
                  <path d="M22.0515 33.3354C22.6793 33.3334 23.3004 33.2068 23.8789 32.9629C24.4574 32.7191 24.9817 32.3629 25.4216 31.9149L36.9415 20.3949C37.842 19.4922 38.3477 18.2692 38.3477 16.9941C38.3477 15.719 37.842 14.496 36.9415 13.5933L25.4216 2.07327C24.7489 1.40063 23.892 0.942561 22.959 0.756979C22.0261 0.571396 21.059 0.66664 20.1802 1.03066C19.3014 1.39469 18.5503 2.01114 18.0218 2.80207C17.4933 3.593 17.2113 4.52287 17.2113 5.4741V8.63243H5.46262C4.18771 8.63392 2.96544 9.14104 2.06394 10.0425C1.16244 10.944 0.655319 12.1663 0.653824 13.4412V20.547C0.655319 21.8219 1.16244 23.0441 2.06394 23.9456C2.96544 24.8471 4.18771 25.3543 5.46262 25.3558H17.2113V28.5141C17.2013 29.4675 17.4795 30.4018 18.0092 31.1945C18.539 31.9873 19.2958 32.6017 20.1805 32.9572C20.7732 33.2054 21.409 33.3339 22.0515 33.3354ZM22.0477 3.16772C22.346 3.16951 22.6409 3.23084 22.9151 3.34812C23.1894 3.46539 23.4375 3.63624 23.6448 3.85065L35.1648 15.3706C35.5945 15.8017 35.8358 16.3855 35.8358 16.9941C35.8358 17.6027 35.5945 18.1865 35.1648 18.6175L23.6448 30.1375C23.3237 30.4588 22.9145 30.6776 22.469 30.7663C22.0236 30.8549 21.5618 30.8095 21.1422 30.6357C20.7225 30.462 20.3638 30.1676 20.1114 29.79C19.8591 29.4123 19.7244 28.9683 19.7244 28.5141V24.0992C19.7244 23.766 19.592 23.4464 19.3563 23.2107C19.1207 22.9751 18.8011 22.8427 18.4678 22.8427H5.46262C4.85401 22.8418 4.27057 22.5997 3.84023 22.1694C3.40988 21.739 3.16774 21.1556 3.16691 20.547V13.4412C3.16774 12.8326 3.40988 12.2492 3.84023 11.8188C4.27057 11.3885 4.85401 11.1463 5.46262 11.1455H18.4678C18.8011 11.1455 19.1207 11.0131 19.3563 10.7775C19.592 10.5418 19.7244 10.2222 19.7244 9.88897V5.4741C19.7158 5.01812 19.847 4.57043 20.1003 4.19124C20.3537 3.81205 20.7172 3.51954 21.1418 3.35306C21.4286 3.23221 21.7365 3.16923 22.0477 3.16772Z" fill="white" />
                </svg>
              </Link>
            </div>
          </div>
        </div>
      </div>

    </>
  );
};

export default ChosenStory;
